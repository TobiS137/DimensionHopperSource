-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Vært: mysql53.unoeuro.com
-- Genereringstid: 25. 04 2024 kl. 08:31:00
-- Serverversion: 8.0.36-28
-- PHP-version: 8.1.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kwazyddu_dk_db_dimension_hopper`
--

-- --------------------------------------------------------

--
-- Struktur-dump for tabellen `leaderboard`
--

CREATE TABLE `leaderboard` (
  `id` int NOT NULL,
  `record` text NOT NULL,
  `player_name` text NOT NULL,
  `level_id` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data dump for tabellen `leaderboard`
--

INSERT INTO `leaderboard` (`id`, `record`, `player_name`, `level_id`) VALUES
(59, '00:08.466', 'TobiS137', 0),
(60, '00:07.583', 'TobiS137', 1),
(62, '00:23.450', 'Pratik', 0),
(63, '00:11.499', 'Pratik', 1),
(64, '00:07.983', 'Patter', 0),
(66, '00:21.449', 'Pawick', 0),
(67, '00:06.566', 'Crosgaard', 0),
(70, '00:06.462', 'Crosgaard', 1),
(75, '00:09.166', 'Paw ', 0),
(84, '00:10.717', 'xXGAMERXx', 0),
(85, '00:17.601', 'xXGAMERXx', 1),
(86, '00:10.275', 'Mango', 0),
(87, '00:10.419', 'FørstePlads', 0),
(88, '00:07.266', 'FørstePlads', 1),
(103, '00:13.449', 'AmazingGamer', 0),
(108, '00:07.199', 'BedreEndTjobs', 0),
(110, '00:06.949', 'BedreEndTjobs', 1),
(116, '00:24.360', 'DAO!', 0),
(117, '00:11.249', 'AmazingGamer', 1),
(119, '00:07.242', 'DAO!', 1);

--
-- Begrænsninger for dumpede tabeller
--

--
-- Indeks for tabel `leaderboard`
--
ALTER TABLE `leaderboard`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `composite_index` (`player_name`(767),`level_id`) USING BTREE;

--
-- Brug ikke AUTO_INCREMENT for slettede tabeller
--

--
-- Tilføj AUTO_INCREMENT i tabel `leaderboard`
--
ALTER TABLE `leaderboard`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
